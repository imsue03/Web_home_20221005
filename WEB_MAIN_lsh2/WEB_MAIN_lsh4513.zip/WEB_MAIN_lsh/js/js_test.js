var jb = 'hi'; //변수 선언 후 주석 가능(한줄 주석석)
var a = 1;
var b;
b = 5;
c = 10;